enum
{
	// string table definitions
	IDS_COLORPICKER = 10000,
	_DUMMY_ELEMENT_
};
