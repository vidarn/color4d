#ifndef _Xpalette_H_
#define _Xpalette_H_

enum
{
	PALETTESHADER_PALETTE_ID	= 1000,
	PALETTESHADER_COLOR_ID		= 1001,
};

#endif
