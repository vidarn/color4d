                                                 
   mmm         ""#                     mm  mmmm  
 m"   "  mmm     #     mmm    m mm    m"#  #   "m
 #      #" "#    #    #" "#   #"  "  #" #  #    #
 #      #   #    #    #   #   #     #mmm#m #    #
  "mmm" "#m#"    "mm  "#m#"   #         #  #mmm" 
                                                 
                                                 
--------------------------------

Thanks for downloading Color4D

Help

  To get started, please visit http://vidarnel.com/color4d and take a look at the section labeled "Documentation"

Contact

  If you have any questions regarding the plugin, please contact vidar.nelson@gmail.com


Installation instructions

  To install Color4D, use the download link from https://github.com/vidarn/color4d.
  Unpack the file and place the folder named "Color4D" in your Cinema4D plugins folder, that is
  C:\Program Files\MAXON\CINEMA 4D R15\plugins\ on windows, or 
  /Applications/MAXON/CINEMA 4D R15/plugins/ on OS X.

  After this, the file structure should be
  C:\Program Files\MAXON\CINEMA 4D R15\plugins\Color4D\Color4D.cdl on windows, or 
  /Applications/MAXON/CINEMA 4D R15/plugins/Color4D/Color4D.dylib on OS X.

  Finally, please restart Cinema4D to finish the installation of Color4D.</p>

